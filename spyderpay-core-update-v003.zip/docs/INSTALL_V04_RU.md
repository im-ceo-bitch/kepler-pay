# v0.4: исправленная установка с постоянным Actions v0.2

Ошибка `unverified_bootstrap_archive` не связана с Python, PostgreSQL или тестами.
Встроенный в постоянный workflow установщик разрешает суффикс `-full.zip` только
для фиксированного SHA-256 начального v0.2. Для следующих релизов допускаются только
`spyderpay_core/`, `tests/`, `docs/`, `integrations/`.

**Новый архив: `spyderpay-core-update-v004.zip`.** Не переименовывать в `-full.zip`.
Он содержит накопительно разрешённые исходники v0.2 + v0.3 + v0.4. Установщик,
workflow, git metadata, настройки корня, реальные секреты и зависимости не подменяются.

Перед загрузкой:
1. Удали из корня нераспакованный `spyderpay-core-update-v003-full.zip` и другие
   оставшиеся `spyderpay-core-update-*.zip`. Действующий установщик требует ровно один ZIP.
2. Если `pyproject.toml` ещё v0.2, добавь в существующий массив `dependencies`
   `"PyJWT[crypto]>=2.10,<3"`. Это обязательная новая зависимость v0.3 для OIDC.
   Разрешённый ZIP не может изменять корневой pyproject. Не отключай OIDC тесты.
   При необходимости используй `docs/pyproject-v04.example.toml` как справочник,
   но сохрани собственные настройки проекта. Можно также обновить `version` на `0.4.0`.
3. Загрузи только `spyderpay-core-update-v004.zip` в корень. YML НЕ заменять.
   После загрузки проверь job `verify`, затем `apply`. При падении verify архив
   останется на месте; не обходи тесты. При удалении старого ZIP отдельным коммитом
   может запуститься пустой workflow; это не ошибка новой поставки.

## Миграция и запуск

Только в отдельной prelicense среде и после бэкапа. Старый корневой
`tools/migrate_postgres.py` v0.2 НЕ использовать: он не знает схем v3/v4.
Новый модуль доступен внутри разрешённого каталога:

```sh
SPYDERPAY_ENV=prelicense python -m spyderpay_core.postgres.ops.migrate
# Как администратор БД: psql с безопасной конфигурацией подключения, затем:
# \i spyderpay_core/postgres/ops/runtime_roles.sql
SPYDERPAY_ENV=prelicense python -m spyderpay_core.postgres.api_v3
```

DSN, issuer/JWKS, service keys и прочие секреты передаются через менеджер секретов.
Не указывай рабочие пароли в Git. Конфигурация reverse proxy и администраторская
утилита identity доступны в `spyderpay_core/postgres/ops/`.

PostgreSQL CI должен выполнить тесты, без skips; локальный запуск без psycopg не
является подтверждением миграций. Не запускай тестовые fixtures на реальной БД.
