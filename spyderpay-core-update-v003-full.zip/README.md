# SpyderPay Core 0.3.0 — Block 1 / Security & Ledger Integrity

**Pre-license engineering release.** NOT approved for real money, not independently audited, not integrated with any bank. Separate core repository from Spider Wallet and Spider Blockchain. All test balances are simulated UZS. No crypto keys or seed phrases handled here.

## Cumulative implementation

This release retains v0.1/v0.2 and adds a versioned PostgreSQL security migration, v3 API, server-controlled OIDC identity, durable session revocation, two-stage transaction approvals (new MFA event after the challenge), short-lived operation-bound authorization, v3 HMAC service signing, DB role grants, sealed journals and balance/invoice integrity constraints. The API rejects duplicate security headers, invalid raw targets, duplicate JSON keys and oversized requests. User payment routes cannot be invoked using service HMAC. Only the v3 API is launched by the PostgreSQL entrypoint; v2 factory is regression-only.

Read [three-block roadmap](docs/ROADMAP_RU.md), [API v3](docs/API_V3_RU.md), [security operations](docs/security/BLOCK1_OPERATIONS_RU.md), and [production gates](docs/security/PRODUCTION_GATE_RU.md).

## Build and verify

Python 3.11+, PostgreSQL 16 in CI. `python -m pip install -e '.[dev]'`, then:

```bash
python -m pytest -q tests --ignore=tests/postgres
python -m unittest discover -s scripts/security_gate -v
# Disposable PostgreSQL only; never run destructive test fixtures on shared or production DB.
docker compose -f compose.test.yaml up -d
export SPYDERPAY_TEST_PG_DSN='postgresql://spyder_test:local-test-only-do-not-reuse@127.0.0.1:5436/spyderpay_test'
python -m pytest -q tests/postgres
```

Use a migration administrator and runtime login separately. `python tools/migrate_postgres.py` runs versioned migrations; apply `infrastructure/postgres/runtime_roles.sql` after migration. Provision test identity via `tools/identity_admin.py`. Configure trusted issuer/JWKS, service keys and private database through a secret manager, run `SPYDERPAY_ENV=prelicense python -m spyderpay_core.postgres.api_v3`. No production flag exists. Sandbox credit is disabled by default. See API/security docs for exact request contracts and limitations.

## ZIP installation

Commit the standalone `spyderpay-unpack.yml` at `.github/workflows/spyderpay-unpack.yml`, replacing the previous one of the same name. Upload the exact `spyderpay-core-update-v003-full.zip` to repository root. The pinned SHA-256 binds this release. CI verifies in a read-only job, including PostgreSQL; a second job applies only identical archive bytes after checks succeed and removes the processed ZIP. No workflow code is installed from the ZIP. If main advances or branch protection disallows the push, use a reviewed PR instead; do not weaken branch protection.

## Status

Block 1 adds substantial implemented controls. Local unit and HTTP regression evidence is available; PostgreSQL integration, real IdP end-to-end, real infrastructure, independent security audit, bank integration, KYC/AML and regulatory acceptance remain release gates. See docs. This is not a production-ready claim.
